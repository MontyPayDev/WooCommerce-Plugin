<?php

require_once plugin_dir_path(__FILE__) . '../../abstract/class-wc-abstract-custom-gateway.php';

class WC_Gateway_Custom_Whish extends WC_Abstract_Custom_Gateway {
    /**
 * @var Custom_Payment_Processor_Whish
 */
    protected $payment_processor;
    public function __construct() {
        $this->id                = 'whish_card_gateway';
        $this->method_title      = __('MontyPay - Whish Payment', 'custom-card-payment');
        $this->method_description= __('Collects card details in a whish payment page', 'custom-card-payment');
        parent::__construct();
        $this->has_fields        = true; // we’re adding our own form fields
        $this->icon = 'https://montypaydev.com/global_assets/images/WhishMoneyLogo.png'  ;


        // instantiate your processor
        $this->payment_processor = new Custom_Payment_Processor_Whish(
            $this->get_option('terminal_id'),
            $this->get_option('branch_id'),
            $this->get_option('Api-Key'),
            $this->get_option('Tenant'),
            $this->get_option('merchant_pass')
          
        );
                add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_checkout_styles' ) );
               



        

    }

    public function init_form_fields() {
        
        $this->form_fields['merchant_pass'] = [
            'title'       => __('Merchant Password', 'custom-card-payment'),
            'type'        => 'password',
            'description' => __('Provided by your payment gateway', 'custom-card-payment'),
            'desc_tip'    => true,
        ];
        // Add your custom fields here
        $this->form_fields['terminal_id'] = [
            'title'       => __('Terminal ID', 'custom-card-payment'),
            'type'        => 'text',
            'description' => __('Provided by your payment gateway', 'custom-card-payment'),
            'desc_tip'    => true,
        ];
    
        $this->form_fields['branch_id'] = [
            'title'       => __('Branch ID', 'custom-card-payment'),
            'type'        => 'text',
            'description' => __('Branch assigned to your store', 'custom-card-payment'),
            'desc_tip'    => true,
        ];
        $this->form_fields['Api-Key'] = [
            'title'       => __('Api-Key', 'custom-card-payment'),
            'type'        => 'text',
            'description' => __('Your Api-Key', 'custom-card-payment'),
            'desc_tip'    => true,
        ];
        $this->form_fields['Tenant'] = [
            'title'       => __('Tenant', 'custom-card-payment'),
            'type'        => 'text',
            'description' => __('Your Tenant', 'custom-card-payment'),
            'desc_tip'    => true,
        ];
        $this->form_fields['title'] = [
            'title'       => __('Title', 'custom-card-payment'),
            'type'        => 'text',
            'default'     => __('Credit/Debit Card', 'custom-card-payment'),
            'desc_tip'    => true,
        ];
        $this->form_fields['description'] = [
            'title'       => __('Description', 'custom-card-payment'),
            'type'        => 'textarea',
            'default'     => __('Pay with your credit card', 'custom-card-payment'),
            'desc_tip'    => true,
        ];

    }
    


    public function enqueue_checkout_styles() {
        if ( is_checkout() && ! is_wc_endpoint_url() ) {
            wp_enqueue_style(
                'montypay-block-styles',
                plugin_dir_url( __FILE__ ) . '../../assets/css/block.css',
                array(),
                '1.0'
            );
        }
    }
    
// ----------------------------------------------------------------CLASSIC CHECKOUT------------------------------------------------------------------------------------

    /**
     * Output credit card form fields on classic checkout
     */
    public function payment_fields() {
        ?>
             <div class="MontyPayLogo">
                    <label><?php _e('Powered By','custom-card-payment'); ?></label>
                    <img
                        src="https://montypaydev.com/global_assets/images/MontyPayLogo.png"
                        alt="<?php esc_attr_e('MontyPay Logo','custom-card-payment'); ?>"
                        class="MontyPayLogo MontyPayLogo-classic"
                    />
                </div>
    
        <?php
    }
    

   

    /**
     * Process payment on classic checkout
     */
    public function process_payment($order_id ) {

        
  
      // Implement your payment processing logic here
      $response = $this->payment_processor->get_redirect_url($order_id);
      
      // Redirect to the payment page
      if(isset($response['redirect_url']) && $response['redirect_url'] ){
        return array(
            'result'   => 'success',
            'redirect' => $response['redirect_url'],
        );
      }
      else{
      // If redirect URL is not available, handle the code here
          // For example, you can add an error notice and redirect back to checkout
          // wc_add_notice(__('Payment processing failed. Please try again.', 'your-text-domain'), 'error');
          return array(
              'result'   => 'fail',
              'redirect' => wc_get_checkout_url(),
          );
      }
    }
    /**
     * Process the payment after the user is redirected back from the payment gateway
     */
   
}
