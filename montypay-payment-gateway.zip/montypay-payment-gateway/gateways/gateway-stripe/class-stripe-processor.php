<?php
if (!defined('ABSPATH')) exit;
require_once plugin_dir_path(__FILE__) . '../../abstract/class-wc-abstract-custom-gateway.php';

class Custom_Payment_Processor_Stripe {
    private $merchant_key;
    private $merchant_pass;
  

    public $currencies_3dotexponent = ['BHD', 'JOD', 'KWD', 'OMR', 'TND'];
    public $currencies_noexponent = [ 'VND', 'ISK', 'UGX'];

    public function __construct($merchant_key, $merchant_pass) {
        $this->merchant_key  = $merchant_key;
        $this->merchant_pass = $merchant_pass;

       
    
    }


    public function get_hash($order_id, $amount, $currency){

    
        $str_to_hash = $order_id . $amount . $currency . __('Payment Order # ', 'woocommerce') . $order_id . __(' in the store ', 'woocommerce') . $this->merchant_pass;
        $hash = sha1(md5(strtoupper($str_to_hash)));    
        
    
        return $hash;
      }
    

    public function process_payment($order_id) {

      $Logger = new WC_Logger();
      $Logger->info('Processing payment for order ID: ' . $order_id ,['source' => 'stripe-apyment']);
  
      // Implement your payment processing logic here
      $response = $this->get_redirect_url($order_id);
      
      // Redirect to the payment page
      if(isset($response['redirect_url']) && $response['redirect_url'] ){
        return array(
            'result'   => 'success',
            'redirect' => $response['redirect_url'],
        );
      }
      else{
      // If redirect URL is not available, handle the code here
          // For example, you can add an error notice and redirect back to checkout
          // wc_add_notice(__('Payment processing failed. Please try again.', 'your-text-domain'), 'error');
          return array(
              'result'   => 'fail',
              'redirect' => wc_get_checkout_url(),
          );
      }
    }
    public function get_redirect_url($order_id){
        $logger = new WC_Logger();
        $logger ->info('hello from get_redirect_url ' . $order_id ,['source' => 'stripe-payment']);

        $order = wc_get_order($order_id);
        
        $customer = array(
            'name' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
            'email' => $order->get_billing_email(),
        );
    
        $billing_address = array(
            'country' => $order->get_billing_country() ? $order->get_billing_country() : 'NA',
            'state' => $order->get_billing_state() ? $order->get_billing_state() : 'NA',
            'city' => $order->get_billing_city() ? $order->get_billing_city() : 'NA',
            'address' => $order->get_billing_address_1() ? $order->get_billing_address_1() : 'NA',
            'zip' => $order->get_billing_postcode() ? $order->get_billing_postcode() : 'NA',
            'phone' => $order->get_billing_phone() ? $order->get_billing_phone() : 'NA',
        );
    
    
        $amount = number_format($order->get_total(), 2, '.', '');
        if (in_array(get_woocommerce_currency(), $this->currencies_noexponent)) {
          $amount = number_format($order->get_total(), 0, '.', '');
        }elseif (in_array(get_woocommerce_currency(), $this->currencies_3dotexponent)) {
    
          $value = round($order->get_total(), 2);
          $amount = number_format($value, 3, '.', '');
    
        }
        $currency = get_woocommerce_currency();
        
    
    
        $order_json = array(
            'number' => "$order_id",
            'description' => __('Payment Order # ', 'woocommerce') . $order_id . __(' in the store ', 'woocommerce'),
            'amount' => $amount, //may troubles
            'currency' => $currency,
        );
    
    
        $request = [
          'merchant_key' => $this->merchant_key,
          'operation'    => 'purchase', //m subs purchase
          'methods'      => array("stripe-js"),
          'order'        => $order_json,
          'customer'     => $customer,
          'billing_address' => $billing_address,
          'success_url' => $order->get_checkout_order_received_url() . '?payment=success', // URL to redirect to after successful payment
          'cancel_url'   => $order->get_view_order_url(), //
          'hash'         => $this->get_hash($order_id, $amount, $currency),
        ];
    
        $logger ->info( 'request ' . json_encode($request) ,['source' => 'stripe-payment']);
        $result = $this->callAPI("https://checkout.montypay.com/api/v1/session", $request, $order_id);
        $logger ->info( 'result ' . json_encode($result) ,['source' => 'stripe-payment']);
    
        if(isset($result->redirect_url) && $result->redirect_url){
    
            $order = wc_get_order($result->order_id);
    
            // $woocommerce->cart->empty_cart();
            // $order->update_status('pending', 'Pending Payment');
    
            return [ 'order_id' => $order_id, 'redirect_url' => $result->redirect_url];
    
        }else{
    
            return ['result' => $result->result, 'error_message' => $result->error_message, 'errors' => $result->errors];
        }
    
    
      }
      public function callAPI( $url, $postFields = null, $orderId = null ) {
        // Prepare JSON payload
        $body = wp_json_encode( $postFields );
    
        // Log request
        error_log( "Request: " . $body );
    
        // Send request via WP HTTP API with a 5-second timeout
        $response = wp_remote_post( $url, [
            'headers'         => [ 'Content-Type'   => 'application/json' ],
            'body'            => $body,
            'timeout'         => 5,  // total seconds before giving up
            'connect_timeout' => 5,  // seconds to establish connection
            'blocking'        => true,
            'redirection'     => 5,
            'sslverify'       => true,
        ] );
    
        // Handle transport errors
        if ( is_wp_error( $response ) ) {
            error_log( 'WP_Error: ' . $response->get_error_message() );
            return null;
        }
    
        // Extract HTTP code and response body
        $httpcode = wp_remote_retrieve_response_code( $response );
        $res      = wp_remote_retrieve_body( $response );
    
        // Log result
        error_log( "Result: " . $res );
        if ( $httpcode !== 200 ) {
            error_log( "httpcode: " . $httpcode );
        }
    
        // Decode JSON and return
        return json_decode( (string) $res );
    }
    
    
 


    
}












add_action('woocommerce_thankyou', function($order_id) {
    if (isset($_GET['payment']) && $_GET['payment'] === 'declined') {
        echo '<div class="woocommerce-error" style="margin:20px 0;">Your order ' . $order_id . ' is received but your payment was declined. Please try a different card or contact your bank.</div>';
    }
});