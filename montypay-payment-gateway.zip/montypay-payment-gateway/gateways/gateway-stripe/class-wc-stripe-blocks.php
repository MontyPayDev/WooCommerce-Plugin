<?php
use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

if (!class_exists('Custom_Stripe_Blocks_Integration')) {
    class Custom_Stripe_Blocks_Integration extends AbstractPaymentMethodType {
        protected $name = 'stripe_card_gateway';
        protected $settings;

        public function initialize() {
            $this->settings = get_option('woocommerce_stripe_card_gateway_settings', []);
        }

        public function is_active() {
            return isset($this->settings['enabled']) && wc_string_to_bool($this->settings['enabled']);
        }

        public function get_payment_method_script_handles() {
            wp_register_style(
                'stripe-card-blocks-style',
                plugins_url('../assets/css/stripe.css', dirname(__FILE__)), // use unique file or name
                [],
                '1.0.0'
            );
            wp_enqueue_style('stripe-card-blocks-style');

            // Enqueue shared utils first
wp_register_script(
    'shared-utils',
    plugins_url('../assets/js/shared-utils.js', dirname(__FILE__)),
    [ 'wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities' ],
    '1.0.0',
    true
);

    
wp_register_script(
    'stripe-card-blocks',
    plugins_url('../assets/js/stripe.js', dirname(__FILE__)),
    [ 'shared-utils' ],
    '1.0.0',
    true
);

    
            return ['stripe-card-blocks'];
        }
    
      

        public function get_payment_method_data() {
            return [
                'title' => $this->settings['title'] ?? __('Pay using Stripe', 'custom-card-payment'),
                'description' => $this->settings['description'] ?? __('Pay using Stripe', 'custom-card-payment'),
                'supports' => ['products'],
                // Add CSS class for targeting
                'cssClass' => 'custom-card-gateway',
                
                
            ];
        }
    }
}