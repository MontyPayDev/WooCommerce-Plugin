<?php
use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

if (!class_exists('Custom_Card_Blocks_Integration')) {
    class Custom_Card_Blocks_Integration extends AbstractPaymentMethodType {
        protected $name = 'custom_card_gateway';
        protected $settings;

        public function initialize() {
            $this->settings = get_option('woocommerce_custom_card_gateway_settings', []);
        }

        public function is_active() {
            return isset($this->settings['enabled']) && wc_string_to_bool($this->settings['enabled']);
        }

        public function get_payment_method_script_handles() {
            wp_register_style(
                's2s-card-blocks-style',
                plugins_url('../assets/css/block.css', dirname(__FILE__)), // use unique file or name
                [],
                '1.0.0'
            );
            wp_enqueue_style('s2s-card-blocks-style');
    
            // Enqueue shared utils first
            wp_register_script(
                'shared-utils',
                plugins_url('../assets/js/shared-utils.js', dirname(__FILE__)),
                [ 'wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities' ],
                '1.0.0',
                true
            );
    
            // Enqueue shared utils first
            wp_register_script(
                's2s-card-blocks',
                plugins_url('../assets/js/blocks.js', dirname(__FILE__)),
                [ 'shared-utils' ],
                '1.0.0',
                true
            );
    
            return ['s2s-card-blocks'];
        }

        public function get_payment_method_data() {
            return [
                'title' => $this->settings['title'] ?? __('Credit/Debit Card', 'custom-card-payment'),
                'description' => $this->settings['description'] ?? __('Pay with your credit card.', 'custom-card-payment'),
                'supports' => ['products'],
                // Add CSS class for targeting
                'cssClass' => 'custom-card-gateway'
            ];
        }
    }
}